package com.gb.store.constant;

/**
 * Grocery Store Application Constants
 */
public class Constant {

    private Constant() {}

    public static final String SUCCESS = "Success";
}
