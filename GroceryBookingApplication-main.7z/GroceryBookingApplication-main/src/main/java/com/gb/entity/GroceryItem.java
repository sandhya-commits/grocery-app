package com.gb.entity;

import javax.persistence.GeneratedValue;

import org.hibernate.annotations.Entity;
import org.hibernate.annotations.Table;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "grocery_items")
public class GroceryItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private BigDecimal price;
    private int inventory;
    private String description;
    // Getters and setters
}
